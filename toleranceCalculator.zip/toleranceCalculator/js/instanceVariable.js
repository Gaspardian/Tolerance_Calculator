let labelForo = document.querySelector('.labelForo');
let labelDimensione = document.querySelector('.labelDimensione');
let labelAlbero = document.querySelector('.labelAlbero');
let titolForo = document.querySelector('.titolForo');
let titolAlbero = document.querySelector('.titolAlbero');
let descrizione = document.querySelectorAll('.descrizione');
let checkEN = document.querySelector("#inglese");
let tastoITA = document.querySelector("#lingIT");
let tastoENG = document.querySelector("#lingEN");
let lettForo = document.querySelector(".lettForo");
let lettAlbero = document.querySelector(".lettAlbero");
let numForo = document.querySelector(".numForo");
let numAlbero = document.querySelector(".numAlbero");
let misura = document.querySelector('#dimensione');

let dimForo = document.querySelector("#dimForo");
let limSupForo = document.querySelector("#limSupForo");
let limInfForo = document.querySelector("#limInfForo");
let scostSupForo = document.querySelector("#scostSupForo");
let scostInfForo = document.querySelector("#scostInfForo");
let ampTollForo = document.querySelector("#ampTollForo");
let dimAlbero = document.querySelector("#dimAlbero");
let limSupAlbero = document.querySelector("#limSupAlbero");
let limInfAlbero = document.querySelector("#limInfAlbero");
let scostSupAlbero = document.querySelector("#scostSupAlbero");
let scostInfAlbero = document.querySelector("#scostInfAlbero");
let ampTollAlbero = document.querySelector("#ampTollAlbero");

let scostAlb = "";
let valoreITAlbero = "";

let scostForo = "";
let valoreITForo = "";

let delta = "";
