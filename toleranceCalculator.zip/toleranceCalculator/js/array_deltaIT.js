function deltaIT(dimensione, grado){
    if(dimensione>1 && dimensione <=3){
        return valori_delta[0][grado-3];
    }
    if(dimensione>3 && dimensione <=6){
        return valori_delta[1][grado-3];
    }
    if(dimensione>6 && dimensione <=10){
        return valori_delta[2][grado-3];
    }
    if(dimensione>10 && dimensione <=14){
        return valori_delta[3][grado-3];
    }
    if(dimensione>14 && dimensione <=18){
        return valori_delta[4][grado-3];
    }
    if(dimensione>18 && dimensione <=24){
        return valori_delta[5][grado-3];
    }
    if(dimensione>24 && dimensione <=30){
        return valori_delta[6][grado-3];
    }
    if(dimensione>30 && dimensione <=40){
        return valori_delta[7][grado-3];
    }
    if(dimensione>40 && dimensione <=50){
        return valori_delta[8][grado-3];
    }
    if(dimensione>50 && dimensione <=65){
        return valori_delta[9][grado-3];
    }
    if(dimensione>65 && dimensione <=80){
        return valori_delta[10][grado-3];
    }
    if(dimensione>80 && dimensione <=100){
        return valori_delta[11][grado-3];
    }
    if(dimensione>100 && dimensione <=120){
        return valori_delta[12][grado-3];
    }
    if(dimensione>120 && dimensione <=140){
        return valori_delta[13][grado-3];
    }
    if(dimensione>140 && dimensione <=160){
        return valori_delta[14][grado-3];
    }
    if(dimensione>160 && dimensione <=180){
        return valori_delta[15][grado-3];
    }
    if(dimensione>180 && dimensione <=200){
        return valori_delta[16][grado-3];
    }
    if(dimensione>200 && dimensione <=225){
        return valori_delta[17][grado-3];
    }
    if(dimensione>225 && dimensione <=250){
        return valori_delta[18][grado-3];
    }
    if(dimensione>250 && dimensione <=315){
        return valori_delta[19][grado-3];
    }
    if(dimensione>315 && dimensione <=355){
        return valori_delta[20][grado-3];
    }
    if(dimensione>355 && dimensione <=400){
        return valori_delta[21][grado-3];
    }
    if(dimensione>400 && dimensione <=450){
        return valori_delta[22][grado-3];
    }
    if(dimensione>450 && dimensione <=500){
        return valori_delta[23][grado-3];
    }
};

